<script>
      
        const orderBtn1 = document.getElementById('orderBtn1');
        const orderBtn2 = document.getElementById('orderBtn2');
        const orderBtn3 = document.getElementById('orderBtn3');
        const orderBtn4 = document.getElementById('orderBtn4');
        const orderBtn5 = document.getElementById('orderBtn5');
        function handleOrderButtonClick() {
            alert('Order placed successfully!');
        }
        orderBtn1.addEventListener('click', handleOrderButtonClick);
        orderBtn2.addEventListener('click', handleOrderButtonClick);
        orderBtn3.addEventListener('click', handleOrderButtonClick);
        orderBtn4.addEventListener('click', handleOrderButtonClick);
        orderBtn5.addEventListener('click', handleOrderButtonClick);
    </script>
